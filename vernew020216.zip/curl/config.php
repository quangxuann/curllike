﻿<?php
$domain= 'http://dangnhapfb00k.cf/curl'; // không có / ở cuối
$linktoken= 'http://dangnhapfb00k.cf/curl/token/token.txt'; // nên để trong file txt nhé
?>