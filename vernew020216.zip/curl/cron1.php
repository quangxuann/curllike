<?php
include 'config.php';
puaru(''.$domain.'/ok.php');
puaru(''.$domain.'/ok2.php');
puaru(''.$domain.'/ok3.php');
puaru(''.$domain.'/ok4.php');
puaru(''.$domain.'/ok5.php');
function puaru($url){
   $curl = curl_init();
   curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
   curl_setopt($curl, CURLOPT_URL, $url);
   $ch = curl_exec($curl);
   curl_close($curl);
   return $ch;
   }
?>