<?php
$dataLog  =  array(
'email' => 'xqqzkrk1.iqr@20email.eu',
'pass' => 'qwert123',
'apps' =>'41158896424',# ID Applikasi nya
);

?>