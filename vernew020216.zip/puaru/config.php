<?php
$domain= 'http://dangnhapfb00k.cf/puaru'; // không có / ở cuối
$linktoken= 'http://dangnhapfb00k.cf/curl/token/token.txt'; // nên để trong file txt nhé
$id_puaru='100005248606381'; // ID User VIP
$limitlike='500000'; // Số Lượng Like
?>