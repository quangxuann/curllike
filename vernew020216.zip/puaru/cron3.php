<?php
include 'config.php';
puaru(''.$domain.'/ok8.php');
puaru(''.$domain.'/ok9.php');
puaru(''.$domain.'/ok10.php');
puaru(''.$domain.'/ok11.php');
puaru(''.$domain.'/ok12.php');
function puaru($url){
   $curl = curl_init();
   curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
   curl_setopt($curl, CURLOPT_URL, $url);
   $ch = curl_exec($curl);
   curl_close($curl);
   return $ch;
   }
?>