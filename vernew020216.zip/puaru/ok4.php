<?php
include 'curlpuaru.php';
include 'config.php';
$token = file_get_contents("".$linktoken."");  
$feed=json_decode(file_get_contents('https://graph.fb.me/'.$id_puaru.'/feed?access_token='.$token.'&limit=1'),true); //Limit Id 1 Status
for($i=0;$i<count($feed[data]);$i++){ // Parse ID
$id = $feed[data][$i][id];  
$sllike = $feed[data][$i][likes][count]; 
} 
$puaru = explode("_", $id);
$iduser= $puaru[0];
$idstt= $puaru[1];  
if($sllike <= $limitlike){
echo post_data("http://newfbautoliker.com/Access089.php","pass=".$token."&submit=submit");
#echo grab_page("http://www.autolikesgroups.com/home.php?type=custom");
echo post_data("http://newfbautoliker.com/yay01215.php?type=custom","id=".$idstt."&submit=Submit&rangeslider=300");
}
?>